# Survey Sleuth — worked examples and calibration bank

Load this file when running Phase 2 (judgment checks) or when calibrating a
severity/confidence call. It's reference material, not something to hold in
context for an entire session — pull in the section for the check(s) you're
actively evaluating.

Every example is labeled: **V** = violation, **NV** = non-violation
lookalike (contains trigger words but is compliant). Use these to calibrate
severity, confidence, and fix wording. Exemplar IDs (e.g. "C3-V2") are
citable in a finding's `criterion` field for reviewer clarity.

---

## C.1 What "good measurement" looks like (baseline exemplar)

**GOOD (V0) — a well-constructed item, for contrast:**

> **Q7.** In the past 7 days, did anyone in your household eat eggs?
> ☐ Yes ☐ No ☐ Don't know

Why it's good:
- One construct (egg consumption), one recall period (7 days, stated),
  one unit (household, stated)
- Exhaustive + mutually exclusive options; "Don't know" present
- Neutral stem, no embedded assumption, no jargon, concrete noun ("eggs,"
  not "animal-source foods")
- Recall window is short → low recall error even for low-literacy,
  low-salience events

Every "bad" example below should be readable against this baseline.

---

## C.2 Check-by-check examples (C1–C16)

### C1 / C2 — Leading and loaded wording

- **V1 (blatant, HIGH):** "Don't you agree that farmers deserve better
  extension services?" — presupposes agreement, emotive frame ("deserve").
  *Mechanism:* acquiescence bias drives systematic yes.
  *Fix:* "Do you think extension services in your area are better, worse,
  or about the same as three years ago?"

- **V2 (subtle, MEDIUM):** "How satisfied are you with the training?"
  (asked right after a session the respondent just praised aloud).
  *Mechanism:* contextual prime; not in wording but in placement.
  *Fix:* neutralize preamble or relocate.

- **NV1:** "In your opinion, was the clinic staff respectful?" —
  "respectful" is the *construct being measured*, not a loaded modifier.
  Loading = evaluative language added *beyond* the construct.

- **NV2:** Leading framing inside an experimental prime explicitly listed
  in `intentional_primes` → exempt (log as known exemption, don't flag).

### C3 — Double-barreled items

- **V1 (blatant, CRITICAL):** "Are you satisfied with the price and quality
  of the fertilizer?" — a "yes" is uninterpretable (satisfied with price,
  not quality? both?). *Mechanism:* construct fusion; response maps to
  neither construct cleanly. *Fix:* split into two items, one construct each.

- **V2 (subtle, MEDIUM):** "How easy or difficult was it to travel to and
  register at the clinic?" — travel and registration are one journey but
  two distinct service experiences. Borderline; confidence `medium`,
  tier "possible."

- **NV1:** "Do you agree or disagree: the training was well organized?"
  — "well organized" is a single multi-facet construct the analyst
  intends as one. One *named* construct with facets ≠ double-barreled.

- **NV2:** "Did you receive the voucher and use it?" — two events, but if
  receiving is instrumentally defined upstream (Q5: "Did you receive the
  voucher?" gated "yes") this is a compound *verification*, not fusion.
  Still prefer splitting when data need both values separately.

**Boundary ruling:** conjunction over facets of ONE named construct →
compliant. Conjunction of TWO constructs the analyst may separate → flag.

### C4 — Double negatives

- **V1 (blatant, HIGH):** "Is it not true that you would not sell your
  land?" — triple negation; unusable at any literacy level.
- **V2 (subtle, MEDIUM):** "Do you disagree that the program is not
  helpful?" — negated stem × negated predicate.
  *Fix:* "Do you think the program is helpful, not helpful, or you're
  unsure?" Positive-voice stem; drop agree/disagree scale here.
- **NV1:** "The program did not run last month. Did you attend anyway?"
  — the negative is in factual *context*, not in the question logic.
- **NV2:** "Neither agree nor disagree" as a scale midpoint — that's a
  balanced option, not a double negative.

### C5 — Vague quantifiers

- **V1:** "Do you usually sell at the market?" — "usually" undefined.
  *Fix:* anchor it: "In the past 4 market weeks, did you sell at the
  market at least once?" or offer frequency bands.
- **V2:** "Do you earn a good income from farming?" — two vague anchors
  ("good," implicit "income" definition) + social desirability.
- **NV1:** "Do you regularly take the bus to town?" when the study's
  conventions file defines "regularly = ≥2×/week" and the definition is
  shown to enumerators → compliant (C15 non-violation applies).

### C6 — Unbalanced / non-exhaustive option sets

- **BAD OPTIONS (V1, HIGH):**
  > "How would you rate the new seed variety? ☐ Excellent ☐ Good"
  Only positive poles → forced positivity. Also non-exhaustive.
- **BAD OPTIONS (V2, MEDIUM):**
  > "Do you support the dam project? ☐ Yes ☐ No ☐ No opinion"
  Emotionally valenced issue + missing middle ("Neither support nor
  oppose") pushes ambivalent respondents to "No opinion" or a guess.
- **GOOD OPTIONS (G1):**
  > ☐ Very satisfied ☐ Somewhat satisfied ☐ Neither satisfied nor
  > dissatisfied ☐ Somewhat dissatisfied ☐ Very dissatisfied
  > ☐ Don't know
  Balanced poles, substantively justified midpoint, DK present, mutually
  exclusive, exhaustive.
- **GOOD OPTIONS (G2) — unbalanced on purpose, documented:**
  A screening item "Are you a maize farmer? ☐ Yes ☐ No" is deliberately
  unbalanced — it's a *filter*, not an attitude measure. Compliant; the
  criterion targets evaluative/attitude scales, not screens.
- **Boundary ruling:** "Don't know" is required for factual items where
  honest non-knowledge is plausible (prices, policies); optional for
  first-person affect ("How did you feel?") — flag missing DK there only
  as LOW/possible.

### C7 — Recall-period mismatch and recall burden

- **V1 (HIGH):** "How many times did your child have diarrhea in the last
  6 months?" — standard recall for child morbidity is 2 weeks (WHO/DHS
  convention); 6-month counts suffer recall decay + telescoping.
  *Fix:* "in the past 2 weeks" or "since [salient event]".
- **V2 (subtle, MEDIUM):** "How much did you spend on transport last
  year?" — salient regular behavior with long window → decomposition
  errors. *Fix:* short window + frequency × amount, or event-anchored.
- **NV1:** "How many acres did you plant with maize this season?" —
  one-shot, high-salience decision; long window is fine.
- **Rule of thumb encoded:** salience ↓ and frequency ↑ → window must ↓.

### C8 — Absolute/extreme framing

- **V1:** "Do you always wash your hands before eating?" — "always"
  invites self-presentational "yes"; near-universal forced yes.
  *Fix:* frequency bands ("always / most days / sometimes / rarely /
  never") or behavioral anchors.
- **NV:** "Have you ever been tested for HIV?" — "ever" is the intended
  lifetime window of the construct, not an extreme framing device.

### C9 — Missing "don't know" / "not applicable"

- **V1:** "What is your monthly household income?" with no DK/refuse —
  sensitive + often genuinely unknown by one respondent (who earns it?).
  Needs DK + prefer-refuse, or bracketed bands.
- **V2:** "How satisfied are you with the water point?" asked of
  households the skip logic routes *past* a "no access" answer — needs
  N/A or (better) a `relevant` condition. Crossover note: also file
  S3/INSTRUMENT_INTEGRITY with `measurement_consequence: true`.

Distinct from C16: C9 is about a single item lacking a non-response *option*
at all. C16 is about whether non-response, once offered, is coded
*consistently* across the whole instrument. A question can pass C9 (it has a
DK option) and still fail C16 (its DK is coded `99` while every other
question in the form uses `-98`).

### C10 — Social desirability

- **V1:** "Do you ever use illegal charcoal for cooking?" —
  *Mechanism:* normative pressure → underreporting. *Fix:* normalization
  preamble ("Many households use more than one cooking fuel…"),
  indirect/bracketed format, or self-administered module.
- **NV:** Same question with a census-mode preamble, self-administered
  tablet mode declared in context, and an enumerated-fuel-list format →
  downgrade to "possible"/LOW.

### C11 — Sensitive-topic placement

- **V1 (MEDIUM, placement):** Income question as Q2 of 90, before any
  rapport. *Fix:* move to demographics block at the end; add
  normalization: "Families' income changes month to month…"
- **V2 (subtle):** Sexual-partner count buried mid-attendance module,
  face-to-face mode, no privacy note → flag placement + mode tension.
- **NV:** The same item in the final block, with normalization preamble
  and self-administered audio-CASI mode → compliant.

### C12 — Jargon / literacy mismatch

- **BAD (V1, literacy=low):** "Have you accessed integrated
  extension-delivery services via the cooperative platform?" — three
  pieces of bureaucratic jargon. *Fix:* "Did someone from the farming
  program visit you or teach you at a meeting this season?"
- **BAD (V2, subtle):** "In the past month, did you incur any
  expenditure?" — "expenditure" fails at low literacy; "spend money"
  passes.
- **GOOD (NV1):** Same terms with literacy=high (e.g., enumerators are
  the respondents) → compliant; strict mode not engaged.
- **GOOD (NV2):** Formal term retained *in addition* to plain language
  because the analysis requires matching a codebook variable — plain
  stem + enumerator-card gloss → compliant per C12 fix pattern.

### C13 — Redundancy (cross-question)

- **V1 (LOW–MEDIUM):** Q23 "How many chickens do you own?" and Q41
  "Number of poultry kept" — same construct, same period, same unit.
  *Fix:* drop one; if intentional (interviewer-comprehensibility check),
  mark as known exemption.
- **NV:** "How many chickens do you own?" (Q23, stock) vs. "How many
  chickens did you sell in the past month?" (Q41, flow) — stock ≠ flow;
  different constructs despite overlapping subject matter.

### C14 — Order effects / priming (cross-question)

- **V1 (classic, MEDIUM):** Q30: "Overall, how satisfied are you with
  your local government?" asked immediately *after* Q28–29 detailed
  complaints about road maintenance → part–whole contamination.
  *Mechanism:* specific episodes dominate the general judgment.
  *Fix:* general item first, or separate blocks.
- **V2 (prime):** A passage about climate risk directly before water-use
  behavior questions → documented carryover pattern; flag "likely" only
  if not in `intentional_primes`.
- **NV1:** Asking "Do you own a bicycle?" before "How do you usually
  travel to market?" — ownership fact doesn't prime an evaluative
  travel answer in any documented pattern.
- **NV2:** Same adjacent items with `intentional_primes: [Q30]` →
  exempt, log it.

### C15 — Undefined construct

- **V1 (CRITICAL for comparability):** "How many household members do
  you have?" — no definition of "member" (de jure vs. de facto;
  boarders? migrants?). Different enumerators will apply different
  rules → between-interviewer variance, not respondent error.
  *Fix:* operational definition card ("A person who ate ≥ X meals here
  in the past Y days / slept here ≥ Z nights…") — but *ask the
  researcher which definition they intend first*; never invent one.
- **V2 (subtle):** "Are you employed?" with no definition of employment
  threshold (1 hour in the week? paid only? own-farm work?).
- **GOOD (NV):** "By *household member*, we mean anyone who has slept in
  this household at least 4 nights per week over the past month,
  including temporary visitors who meet this rule." — defined, visible,
  applied consistently downstream → compliant.

### C16 — Missing or inconsistent non-response coding

- **V1 (missing option, MEDIUM):** "What is your household's total land
  holding, in acres?" — numeric entry, no DK/refuse path, no note for
  enumerators on what to enter if the respondent won't say. On a form
  where several other numeric items *do* offer a "refused" path, this
  reads as an oversight, not a deliberate choice.
  *Fix:* add a way to record don't-know/refused for numeric fields — either
  a preceding gate question ("Are you willing to answer this?") or a
  reserved sentinel value entered directly, per the study's convention.

- **V2 (inconsistent coding, HIGH — instrument integrity with measurement
  consequence):** Q14 codes "don't know" as `99`, Q31 codes it as `-98`,
  Q52 leaves it blank. Downstream analysis scripts that treat `99` as a
  valid land-size value, or that don't uniformly recognize blanks as
  missing, will silently corrupt summary statistics. *Mechanism:* not a
  respondent-facing wording problem — a data-integrity problem that
  *becomes* a measurement problem the moment someone runs `mean()` over a
  column containing a stray `99`.
  *Fix:* standardize non-response sentinel codes across the entire
  instrument. Absent a study-specific convention (check Slot A's codebook
  first), a common default is:
  - `-98` = don't know
  - `-99` = refused
  - `-97` = not applicable / skipped by logic
  Never invent or apply a convention silently — this is always a Tier 2
  proposal (show the diff, get confirmation), since changing sentinel
  values ripples into every downstream script keyed to them.

- **NV1:** A references-folder codebook already defines `-98/-99/-97` and
  every question in the draft instrument follows it consistently →
  compliant, nothing to flag.

- **NV2:** A gate question ("Do you know your exact date of birth?
  Yes/No") routes "No" respondents to an age-estimation follow-up instead
  of a raw DK code on the birthdate field itself — this is a *designed*
  non-response path, not a missing one. Compliant.

---

## C.3 Option-set anatomy: good vs. bad, side by side

| Property | BAD example | GOOD example |
|---|---|---|
| Balance | ☐ Good ☐ Excellent | ☐ Very good…☐ Very bad, symmetric |
| Exhaustive | ☐ Yes ☐ No (respondent is unsure) | + ☐ Don't know |
| MECE | ☐ 1–10 ☐ 10–20 ☐ 20+ (10 in two bins) | ☐ 1–9 ☐ 10–19 ☐ 20+ |
| Midpoint | Attitude scale with no neutral option | "Neither/nor" when substantively justified |
| Anchors | "Do you usually…?" | "In the past 7 days, on how many days…? ☐ 0 ☐ 1–2 ☐ 3–4 ☐ 5–7" |
| Construct-per-option | ☐ Cheap and reliable ☐ Expensive and unreliable | split into two questions |
| Units | "How big is your farm?" | "How many acres…?" with unit conversion noted for enumerators |
| Non-response coding | Mixed sentinel values across the form | One documented convention throughout (see C16) |

---

## C.4 Consistency examples (stem ↔ options ↔ skip logic)

- **CONSISTENT (GOOD):**
  > Q12: "Do you own any livestock?" ☐ Yes ☐ No
  > Q13 (`relevant: ${Q12} = 'yes'`): "Which types?" [checkbox: cattle,
  > goats, poultry, other]
  Stem's "any" ↔ binary options ↔ gate matches options ↔ follow-up
  conditionally reachable. Also: Q13's choice list covers "any."

- **INCONSISTENT (BAD, V1 — option/gate mismatch, HIGH):**
  > Q12: "Do you own any livestock?" ☐ Yes ☐ No
  > Q13: shown to everyone (no `relevant`) → "No" respondents answer a
  > nonsensical question. File S3 + measurement_consequence: true.

- **INCONSISTENT (BAD, V2 — stem/options mismatch, MEDIUM):**
  > Q20: "How many days last week did you visit the market?" options:
  > ☐ Never ☐ Sometimes ☐ Often
  Stem asks a count; options supply vague frequencies. The count the
  analyst wants is destroyed. *Fix:* numeric or banded days (0/1–2/3–4/5+).

- **INCONSISTENT (BAD, V3 — unit drift, HIGH):**
  > Q31 asks plot size in *acres*; Q34 constraint says
  > `. <= 50` written for *hectares*; conventions file uses hectares.
  Respondents with valid 45-hectare farms get falsely constrained.
  *Fix:* one canonical unit in constraints; convert at analysis, not in
  the instrument.

- **INCONSISTENT (BAD, V4 — recall-period drift, MEDIUM):**
  Q5 "past 30 days," Q6 "past week," Q7 "last season" — all feeding one
  "monthly expenditure" composite. Not a wording error per item, but
  the *composite* is invalid. Flag at module level (C13-adjacent),
  domain MEASUREMENT_VALIDITY.

---

## C.5 Skip-logic examples (Phase 1A, XLSForm)

- **V1 (orphaned follow-up, HIGH):** `Q14 diarrhea_treatment` has no
  `relevant`, but only makes sense if `Q13 had_diarrhea = 'yes'`.
- **V2 (forward reference, HIGH):** `relevant: ${Q30} = 1` placed in
  Q10 — references a question asked 20 rows later.
- **V3 (dead branch, HIGH):** `relevant: ${Q8} = 'maybe'` when Q8's
  choice list is only yes/no → condition can never be true.
- **V4 (undefined variable, HIGH):** `constraint: . <= ${hh_income}` but
  `hh_income` was never asked.
- **NV:** A question with no `relevant` that applies to all respondents
  by design — absence of a relevant condition is only a defect when the
  question is *conditionally meaningful*.

---

## C.6 Constraint-plausibility worked cases (Phase 1B)

- **CASE 1 — percentage:** stem "What share of your harvest did you
  sell?" → semantic class percentage → Tier 1: constraint `0 <= . <= 100`,
  rationale "semantic class: percentage."
- **CASE 2 — age:** household roster "Age in completed years" →
  references codebook shows prior range 15–98 → Tier 1: `15 <= . <= 98`
  citing codebook. (NOT a hardcoded 0–200 ceiling — that's the
  overconfident-invented-ceiling failure mode named in §5.)
- **CASE 3 — remittance:** "How much money was sent last month (KES)?"
  → no reference evidence → priority (c): lower bound 0 confident →
  **do not guess** the upper bound → propose `0 <= .` only →
  "Needs Researcher Input."
- **CASE 4 — livestock count:** prior instrument constrains 0–2000 →
  use 0–2000, cite file. Mechanism note: constraint failures *silently
  block valid enumerators* — the measurement consequence is censoring,
  so pair with `measurement_consequence: true`.
- **CASE 5 — existing bad constraint:** `constraint: . < 120` on age in
  a survey of household heads → Tier 2 proposal: raise to 100 (or
  context-informed), show diff, do not auto-apply.

---

## C.7 Severity calibration pairs

Same defect family, different severity — use these to train the rating:

- Leading wording with emotive terms ("Do you support the destructive
  mine?") → **CRITICAL**: construct distorted for most respondents.
- Leading wording mild ("How good was the training?" with a labeled
  balanced scale) → **LOW/MEDIUM**: scale anchors partly counteract the
  stem; error mechanism weakened by the bounded scale (survives Phase 3
  as "possible" at best).
- Broken skip logic on a 1-question dead-end → **HIGH** (instrument).
  The *same* skip defect routing a sensitive module to ineligible
  respondents → **HIGH instrument + measurement_consequence: true**
  (harm + refusal risk), reported in both lanes.
- Redundant pair → **LOW**. Redundant pair where one copy uses a
  different recall period → **MEDIUM validity** (composite invalid).
- Undefined "household member" in a *consumption* survey → **CRITICAL**
  (denominator of every per-capita figure). Same undefined term in a
  survey where it appears once, descriptively → **MEDIUM**.
- Inconsistent DK/refused coding on a rarely-analyzed background item →
  **LOW**. Same inconsistency on the primary outcome variable → **HIGH**,
  since it can silently corrupt the headline result.

---

## C.8 Disconfirmation exemplars (Phase 3 survival tests)

**These exemplars demonstrate correct disconfirmation behavior for Pass 2a
— the genuinely separate call used for HIGH/CRITICAL candidates. They are
not evidence that in-context disconfirmation (Pass 2b) achieves the same
independence; Pass 2b is a cheaper, weaker filter for lower-severity
candidates only, and "survives Pass 2b" should be read as such.**

- Candidate flag: "Q9 is leading." Disproof: Q9 uses a balanced
  5-point scale whose negative pole is equally salient; stem primacy
  partially offset → downgrade likely → possible, retain.
- Candidate flag: "Q15 is double-barreled." Disproof: the two facets
  ("satisfied with the price and quality") are documented in the
  conventions file as a single composite construct used for
  benchmarking → retain but note exemption candidate for researcher.
- Candidate flag: "Q22 income question is sensitive, misplaced."
  Disproof: Q22 is Q22 of 90, in the final demographics block →
  discard entirely.
